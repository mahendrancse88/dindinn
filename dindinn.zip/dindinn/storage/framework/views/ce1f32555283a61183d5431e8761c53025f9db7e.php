<?php $__env->startSection('content'); ?>
<h1>Vendor</h1>
<table class="table table-bordered ">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Order</th>
      <th scope="col">Client</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($order->id); ?></th>
      <td><?php echo e($order->name); ?></td>
      <td><?php echo e($order->client->name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.masterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\laravel_dindinn\resources\views/vendors/show.blade.php ENDPATH**/ ?>