<?php $__env->startSection('content'); ?>
<h1>Client</h1>
<form action="<?php echo e(route('orders.sendOrder')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="exampleFormControlSelect1">User</label>
    <select class="form-control" name="client_id">
      <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Vendor</label>
    <select class="form-control" name="vendor_id">
      <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Order</label>
    <textarea class="form-control" name="name" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
  <button type="submit" class="btn btn-primary mb-2">Send</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.masterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\laravel_dindinn\resources\views/clients/index.blade.php ENDPATH**/ ?>